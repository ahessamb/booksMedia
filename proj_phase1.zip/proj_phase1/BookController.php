<?php

namespace App\Http\Controllers;

use App\book;
use Illuminate\Http\Request;

class BookController extends Controller
{
    public function index(){
        $books=book::all();
        return view('booksIndex',compact('books'));
    }

    public function show($id){
        $book=book::where('id',$id)->firstOrfail();
        return view('bookShow',compact('book'));
    }
}
