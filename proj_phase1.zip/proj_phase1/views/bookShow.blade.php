
    <!DOCTYPE HTML>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>Book : {{$book->id}}</title>
</head>
<body>
<h3>
{{$book->name}} : {{$book->ISBN}} {{$book->pages}} {{$book->price}} {{$book->published_at}}
</h3>
</body>
</html>
