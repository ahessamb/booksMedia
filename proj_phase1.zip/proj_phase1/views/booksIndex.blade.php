<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>Books</title>
</head>
<body>
<h2>
    @foreach($books as $book)
        {{$book->name}} : {{$book->ISBN}} {{$book->pages}} {{$book->price}} {{$book->published_at}}
        <br>
    @endforeach
</h2>
</body>
</html>
